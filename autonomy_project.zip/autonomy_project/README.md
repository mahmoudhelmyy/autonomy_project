"""
# Autonomous Control for Moebius Challenge

This ROS2 package provides the complete software solution for the autonomous mini-car challenge. It enables the robot to perform multi-lap trajectory following and dynamic obstacle avoidance based on the provided technical specification.

## Dependencies
- A working ROS2 Humble or Iron installation.
- The existing project workspace (`bringup`, `controller`, etc.) must be built and sourced.
- `cv_bridge` (`sudo apt install ros-<distro>-cv-bridge`).
- `opencv-python` (`pip install opencv-python`).

## 1. Build the Package
1.  Place this `autonomy_project` folder inside your `ros2_ws/src` directory.
2.  Navigate to the root of your ROS2 workspace: `cd ~/ros2_ws`
3.  Build the new package: `colcon build --packages-select autonomy_project`
4.  Source the workspace: `source install/setup.bash`

## 2. Run the Project
1.  In one terminal, launch the main robot drivers using the existing bringup launch file:
    ```bash
    ros2 launch bringup bringup.launch.py
    ```
2.  In a **second terminal**, source the workspace again and launch the autonomous challenge logic:
    ```bash
    source install/setup.bash
    ros2 launch autonomy_project challenge.launch.py
    ```
The robot will now begin its autonomous routine.

## 3. Critical: Parameter Tuning
Before the competition, you **must** tune the following parameters for optimal performance:

### Obstacle Detection
- **File**: `autonomy_project/autonomy_project/obstacle_detector_node.py`
- **Parameters**: `RED_LOWER1`, `RED_UPPER1`, `RED_LOWER2`, `RED_UPPER2`, `GREEN_LOWER`, `GREEN_UPPER`.
- **Action**: These HSV color ranges are placeholders. You must use a color picker tool to find the correct values for the red and green blocks under the actual lighting conditions of the arena.

### Navigation
- **File**: `autonomy_project/autonomy_project/navigation_node.py`
- **Parameters**:
    - `LINEAR_SPEED`: The robot's forward speed during wall-following.
    - `DESIRED_WALL_DIST`: How far to stay from the inner wall (in meters).
    - `OBSTACLE_DIST_THRESH`: How close to get to an obstacle before starting an avoidance maneuver.
    - `PID_KP`, `PID_KI`, `PID_KD`: Gains for the steering controller. Adjust these to make turning smoother or more aggressive.
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import message_filters
from autonomy_project.msg import Obstacle

# IMPORTANT: These HSV color ranges are placeholders and MUST be tuned
# for the specific lighting conditions of the competition arena.
RED_LOWER1 = np.array([0, 150, 100])
RED_UPPER1 = np.array([10, 255, 255])
RED_LOWER2 = np.array([170, 150, 100])
RED_UPPER2 = np.array([180, 255, 255])
GREEN_LOWER = np.array([40, 100, 80])
GREEN_UPPER = np.array([80, 255, 255])

class ObstacleDetectorNode(Node):
    """
    This node detects colored obstacles using the RealSense camera.
    It subscribes to synchronized color and depth images, identifies red and
    green objects, calculates their position, and publishes the information.
    """
    def __init__(self):
        super().__init__('obstacle_detector_node')
        self.bridge = CvBridge()
        self.obstacle_pub = self.create_publisher(Obstacle, '/obstacles', 10)

        # Subscribers for synchronized color and depth images
        self.image_sub = message_filters.Subscriber(self, Image, '/camera/color/image_raw')
        self.depth_sub = message_filters.Subscriber(self, Image, '/camera/depth/image_aligned_to_color/image_raw')
        
        # Synchronize messages by timestamp
        self.ts = message_filters.ApproximateTimeSynchronizer(
            [self.image_sub, self.depth_sub], 10, 0.1)
        self.ts.registerCallback(self.image_callback)
        
        self.get_logger().info('Obstacle Detector Node has been started.')

    def image_callback(self, img_msg, depth_msg):
        """
        Callback function for synchronized image messages.
        """
        cv_image = self.bridge.imgmsg_to_cv2(img_msg, 'bgr8')
        depth_image = self.bridge.imgmsg_to_cv2(depth_msg, '32FC1')
        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
        
        h, w, _ = cv_image.shape

        # Create masks for red and green colors
        mask_r1 = cv2.inRange(hsv_image, RED_LOWER1, RED_UPPER1)
        mask_r2 = cv2.inRange(hsv_image, RED_LOWER2, RED_UPPER2)
        red_mask = cv2.bitwise_or(mask_r1, mask_r2)
        green_mask = cv2.inRange(hsv_image, GREEN_LOWER, GREEN_UPPER)

        self.find_and_publish_obstacle(red_mask, "red", depth_image, w)
        self.find_and_publish_obstacle(green_mask, "green", depth_image, w)

    def find_and_publish_obstacle(self, mask, color, depth_image, width):
        """
        Finds the largest contour in a mask, calculates its position, and publishes it.
        """
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours: return

        contour = max(contours, key=cv2.contourArea)
        if cv2.contourArea(contour) < 1000: return # Filter small noise

        M = cv2.moments(contour)
        if M["m00"] == 0: return
        
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])

        # Get distance from the depth image (convert mm to meters)
        distance = depth_image[cy, cx] / 1000.0
        
        if np.isnan(distance) or np.isinf(distance) or distance <= 0.2: return
        
        # Approximate angle based on horizontal position in the image (69.4 deg FoV for D455)
        fov_h_rad = np.deg2rad(69.4) 
        angle = (float(cx) / width - 0.5) * fov_h_rad
        
        msg = Obstacle()
        msg.color = color
        msg.distance = float(distance)
        msg.angle = angle
        self.obstacle_pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = ObstacleDetectorNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

# ==============================================================================
# File: autonomy_project/autonomy_project/navigation_node.py
# ==============================================================================
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from autonomy_project.msg import Obstacle
import numpy as np
import math

class PIDController:
    """A simple PID controller."""
    def __init__(self, Kp, Ki, Kd, setpoint):
        self.Kp, self.Ki, self.Kd = Kp, Ki, Kd
        self.setpoint = setpoint
        self.prev_error, self.integral = 0, 0
    def calculate(self, current_value, dt):
        error = self.setpoint - current_value
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt
        self.prev_error = error
        return self.Kp * error + self.Ki * self.integral + self.Kd * derivative

class NavigationNode(Node):
    """
    Main logic node for the autonomous challenge. Handles wall-following,
    lap counting, and obstacle avoidance.
    """
    def __init__(self):
        super().__init__('navigation_node')
        
        # --- Tunable Parameters ---
        self.LINEAR_SPEED = 0.22
        self.DESIRED_WALL_DIST = 0.35
        self.OBSTACLE_DIST_THRESH = 0.7
        self.PID_KP, self.PID_KI, self.PID_KD = 1.8, 0.0, 0.6
        
        # --- State Machine and Lap Counting ---
        self.state = "INITIALIZING"
        self.direction, self.start_pose, self.last_yaw = None, None, None
        self.lap_count, self.total_yaw = 0, 0.0
        self.maneuver_start_time, self.maneuver_state = None, 0

        self.pid = PIDController(self.PID_KP, self.PID_KI, self.PID_KD, self.DESIRED_WALL_DIST)
        
        # --- Publishers and Subscribers ---
        self.cmd_pub = self.create_publisher(Twist, '/controller/cmd_vel', 10)
        self.scan_sub = self.create_subscription(LaserScan, '/scan_raw', self.scan_callback, 10)
        self.odom_sub = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        self.obstacle_sub = self.create_subscription(Obstacle, '/obstacles', self.obstacle_callback, 10)
        
        self.get_logger().info('Navigation Node has been started.')

    def odom_callback(self, msg):
        """Callback for odometry messages to handle lap counting."""
        if self.start_pose is None:
            self.start_pose = msg.pose.pose
            self.last_yaw = self.get_yaw_from_pose(self.start_pose)
            return

        current_yaw = self.get_yaw_from_pose(msg.pose.pose)
        dyaw = current_yaw - self.last_yaw
        if dyaw > np.pi: dyaw -= 2 * np.pi
        if dyaw < -np.pi: dyaw += 2 * np.pi
        self.total_yaw += dyaw
        self.last_yaw = current_yaw
        
        lap_threshold = 1.95 * np.pi
        start_dist = np.hypot(msg.pose.pose.position.x - self.start_pose.position.x, 
                              msg.pose.pose.position.y - self.start_pose.position.y)

        if (self.direction == 'CW' and self.total_yaw < -lap_threshold and start_dist < 0.5) or \
           (self.direction == 'CCW' and self.total_yaw > lap_threshold and start_dist < 0.5):
            self.lap_count += 1
            self.total_yaw = 0
            self.get_logger().info(f"LAP {self.lap_count} COMPLETED!")

    def obstacle_callback(self, msg):
        """Callback for detected obstacles."""
        if self.state == "FOLLOWING_WALL" and msg.distance < self.OBSTACLE_DIST_THRESH:
            self.get_logger().info(f"Obstacle detected: {msg.color}. Starting avoidance.")
            self.state = "AVOIDING_RIGHT" if msg.color == "red" else "AVOIDING_LEFT"
            self.maneuver_state = 0

    def scan_callback(self, msg):
        """Main callback for LiDAR data, drives the state machine."""
        if self.lap_count >= 3:
            if self.state != "FINISHED":
                self.get_logger().info("Mission Complete: 3 laps finished. Stopping.")
                self.state = "FINISHED"
            self.publish_twist(0.0, 0.0)
            return
            
        if self.state == "INITIALIZING": self.initialize_direction(msg)
        elif self.state == "FOLLOWING_WALL": self.follow_wall(msg)
        elif self.state == "AVOIDING_RIGHT": self.avoid_maneuver(-0.7) # Negative for right
        elif self.state == "AVOIDING_LEFT": self.avoid_maneuver(0.7)  # Positive for left
    
    def initialize_direction(self, scan_msg):
        """Automatically determines the direction of travel at startup."""
        ranges = np.array(scan_msg.ranges)
        right_view = ranges[int(len(ranges) * 0.75):]
        left_view = ranges[:int(len(ranges) * 0.25)]
        min_right = np.min(right_view[np.isfinite(right_view)])
        min_left = np.min(left_view[np.isfinite(left_view)])
        self.direction = 'CW' if min_right > min_left else 'CCW'
        self.state = "FOLLOWING_WALL"
        self.get_logger().info(f"Direction determined: {self.direction}")

    def follow_wall(self, scan_msg):
        """Uses a PID controller to follow the inner wall."""
        ranges = np.array(scan_msg.ranges)
        angle_min_idx, angle_max_idx = (int(np.deg2rad(240)/scan_msg.angle_increment), int(np.deg2rad(300)/scan_msg.angle_increment)) if self.direction == 'CW' else (int(np.deg2rad(60)/scan_msg.angle_increment), int(np.deg2rad(120)/scan_msg.angle_increment))
        wall_slice = ranges[angle_min_idx:angle_max_idx]
        wall_slice = wall_slice[np.isfinite(wall_slice)]
        if len(wall_slice) == 0: return
        current_dist = np.min(wall_slice)
        angular_z = self.pid.calculate(current_dist, 0.1) # dt is approx 0.1s
        if self.direction == 'CW': angular_z *= -1
        self.publish_twist(self.LINEAR_SPEED, angular_z)

    def avoid_maneuver(self, turn_angular_z):
        """Executes a timed maneuver to bypass an obstacle."""
        current_time = self.get_clock().now()
        if self.maneuver_state == 0: # Start turn
            self.publish_twist(0.1, turn_angular_z); self.maneuver_start_time = current_time; self.maneuver_state = 1
        elif self.maneuver_state == 1 and (current_time - self.maneuver_start_time).nanoseconds > 1.5e9: self.maneuver_state = 2
        elif self.maneuver_state == 2: # Go straight
            self.publish_twist(self.LINEAR_SPEED, 0.0); self.maneuver_start_time = current_time; self.maneuver_state = 3
        elif self.maneuver_state == 3 and (current_time - self.maneuver_start_time).nanoseconds > 2.0e9: self.maneuver_state = 4
        elif self.maneuver_state == 4: # Turn back
            self.publish_twist(0.1, -turn_angular_z); self.maneuver_start_time = current_time; self.maneuver_state = 5
        elif self.maneuver_state == 5 and (current_time - self.maneuver_start_time).nanoseconds > 1.5e9:
            self.get_logger().info("Avoidance complete. Resuming wall following."); self.state = "FOLLOWING_WALL"

    def publish_twist(self, linear, angular):
        """Publishes a Twist message to control the robot's chassis."""
        msg = Twist(); msg.linear.x = linear; msg.angular.z = float(angular); self.cmd_pub.publish(msg)
            
    def get_yaw_from_pose(self, pose):
        """Extracts the yaw angle from a quaternion."""
        q = pose.orientation
        return math.atan2(2.0 * (q.w * q.z + q.x * q.y), 1.0 - 2.0 * (q.y * q.y + q.z * q.z))

def main(args=None):
    rclpy.init(args=args)
    node = NavigationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()